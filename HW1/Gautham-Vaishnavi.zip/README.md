## HW 1
---

### MSApriori

```
python3 HW1.py data.txt params.txt output.txt
```